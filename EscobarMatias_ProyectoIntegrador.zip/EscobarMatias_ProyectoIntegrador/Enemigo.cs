﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscobarMatias_ProyectoIntegrador
{
    public class Enemigo
    {
        public string Nombre { get; private set; }
        public int Vida { get; private set; }
        public int AtaqueBase { get; private set; }
        public bool EstaVivo { get; private set; }

        public Enemigo(string nombre, int vida, int ataque)
        {
            Nombre = nombre;
            Vida = Math.Max(0, vida);
            AtaqueBase = Math.Max(0, ataque);
            EstaVivo = Vida > 0;
        }
        public int Atacar() => AtaqueBase;
        public void RecibirDanio(int danio)
        {
            Vida = Math.Max(0, Vida - danio);
            EstaVivo = Vida > 0;
        }
        public static Enemigo CrearPrototipo(string nombre, int vida, int ataque)
        {
            return new Enemigo(nombre, vida, ataque);
        }
    }
}
