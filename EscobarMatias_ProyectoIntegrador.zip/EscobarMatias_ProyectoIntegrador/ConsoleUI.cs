﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscobarMatias_ProyectoIntegrador
{
    public class ConsoleUI : IUserInterface
    {
        public void MostrarMensaje(string mensaje)
        {
            Console.WriteLine($"[INFO] {mensaje}");
        }

        public string LeerEntrada()
        {
            return Console.ReadLine() ?? string.Empty;
        }
        public void EsperarTecla()
        {
            Console.WriteLine("\n[Presiona Enter para continuar...]");
            Console.ReadLine(); 
        }

        public void MostrarEstado(Personaje personaje, Enemigo enemigo)
        {
            Console.WriteLine("\n--- ESTADO ACTUAL ---");
            Console.WriteLine($"Héroe: {personaje.Nombre} | HP: {personaje.Vida} | ATK: {personaje.AtaqueBase}");
            if (personaje is Mago m) Console.WriteLine($"      Mana: {m.Mana}");

            Console.WriteLine($"Enemigo: {enemigo.Nombre} | HP: {enemigo.Vida}");
            Console.WriteLine("---------------------\n");
        }
        public int SeleccionarOpcion(Dictionary<int, string> opciones)
        {
            Console.WriteLine("\n-- Elige una Opción --");
            foreach (var kvp in opciones) Console.WriteLine($"[{kvp.Key}] {kvp.Value}");

            Console.Write("Opción: ");
            if (int.TryParse(Console.ReadLine(), out int eleccion) && opciones.ContainsKey(eleccion))
                return eleccion;
            return -1;
        }
        public int SeleccionarItem(IReadOnlyList<Item> items)
        {
            Console.WriteLine("\n--- Inventario ---");
            if (items.Count == 0)
            {
                Console.WriteLine(" (Vacío) ");
                return -1;
            }

            for (int i = 0; i < items.Count; i++)
            {
                Console.WriteLine($"[{i}] {items[i].Nombre}");
            }
            Console.WriteLine($"[{items.Count}] Cancelar");

            Console.Write("Elige un ítem para usar: ");
            if (int.TryParse(Console.ReadLine(), out int indice))
            {
                if (indice >= 0 && indice < items.Count) return indice;
                if (indice == items.Count) return -1;
            }
            return -1;
        }
    }
}
