﻿// See https://aka.ms/new-console-template for more information

using EscobarMatias_ProyectoIntegrador;

public class Program
{
    public static void Main(string[] args)
    {
        IUserInterface consolaUI = new ConsoleUI();
        try
        {
            Console.WriteLine("--- Bienvenido a este mundo de fantasía ---");

            SistemaCombate sistemaCombate = new SistemaCombate();
            GameManager gameManager = new GameManager(sistemaCombate, consolaUI);
            gameManager.IniciarJuego();

            consolaUI.MostrarMensaje("\n--- Juego finalizado. ---");
        }
        catch (Exception ex)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"\n[ERROR CRÍTICO] Ocurrió un error inesperado: {ex.Message}");
            Console.WriteLine("El programa se cerrará por seguridad.");
            Console.ResetColor();
        }
        finally
        {
            Console.WriteLine("Presiona Enter para salir...");
            Console.ReadLine();
        }
    }
}

/* * =================================================================================
 * NOTAS DE LA ENTREGA FINAL
 * =================================================================================
 * * 1. ARQUITECTURA Y DISEÑO:
 * - Se reestructuró todo el proyecto aplicando principios SOLID y patrones de diseño, desacoplando la UI de la lógica del juego mediante la interfaz IUserInterface.
 * - Se creo la clase ConsoleUI que implementa IUserIterface para manejar la interacción con el usuario en consola.
 * - Se creo la clase GameManager para centralizar la lógica principal del juego.
 * - Se aplicó el principio de responsabilidad única (SRP) en todas las clases.
 * - Se mejoró la legibilidad y mantenibilidad del código.
 * * 2. PERSISTENCIA:
 * - Se implementó persistencia en JSON usando System.Text.Json.
 * - Se agregó la clase estática 'GestorDeDatos' para separar la responsabilidad de E/S.
 * - Se incluyó lógica para validar y crear Directorios personalizados según la elección del usuario.
 * * 3. EXCEPCIONES:
 * - Se implementó la excepción personalizada 'JuegoException' para reglas de negocio.
 * - Se protegieron con try-catch los ingresos de datos y operaciones de archivos para asegurar que el programa no se cierre abruptamente ante errores.
 * - Se agregó un manejo global de excepciones en 'Program.cs' para capturar errores inesperados.
 * * 4. NUEVOS ELEMENTOS (Pergamino):
 * - Se creó la clase 'Pergamino' que hereda de 'Item'.
 * - Modificación del Sistema de Combate: Se adaptó la lógica para detectar el uso
 * del pergamino, permitiendo interrumpir el bucle de combate (escapar) sin
 * necesidad de derrotar al enemigo.
 * =================================================================================
 */

