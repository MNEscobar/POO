﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscobarMatias_ProyectoIntegrador
{
    public interface IUserInterface
    {
        void MostrarMensaje(string mensaje);
        void MostrarEstado(Personaje personaje, Enemigo enemigo);
        int SeleccionarOpcion(Dictionary<int, string> opciones);
        string LeerEntrada();
        void EsperarTecla();
        int SeleccionarItem(IReadOnlyList<Item> items);
    }
}
