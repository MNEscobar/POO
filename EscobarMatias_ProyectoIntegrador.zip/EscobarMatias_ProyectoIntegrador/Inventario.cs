﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json.Serialization;

namespace EscobarMatias_ProyectoIntegrador
{
    public class Inventario
    {
        [JsonInclude]
        public List<Item> _items = new List<Item>();

        [JsonIgnore]
        public IReadOnlyList<Item> Items => _items.AsReadOnly();


        public void AgregarItem(Item item)
        {
            if (item != null) _items.Add(item);
        }

        public void EliminarItem(Item item)
        {
            _items.Remove(item);
        }
        public void UsarItem(Personaje objetivo, int indice)
        {
            if (indice  >= 0 && indice < _items.Count)
            {
                var ItemUsar = _items[indice];
                ItemUsar.Usar(objetivo);
                _items.RemoveAt(indice);
            }
        }
    }
}