﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscobarMatias_ProyectoIntegrador
{
    public class AtaqueMagico : IEstrategiaAtaque
    {
        private const int COSTO_MANA = 10;
        public ResultadoAtaque EjecutarAtaque(Personaje atacante)
        {
            if (atacante.IntentarGastarMana(COSTO_MANA))
            {
                Random random = new Random();
                int danioMagico = (atacante.AtaqueBase * 2) + random.Next(5, 16);
                int manaRestante = (atacante as Mago)?.Mana ?? 0;

                string descripcion = $"{atacante.Nombre} invoca una bola de fuego y causa {danioMagico}";
                return new ResultadoAtaque(danioMagico, descripcion);
            }
            else
            {
                int danioBaston = atacante.AtaqueBase - 5;  
                string descripcion = $"{atacante.Nombre} no tiene suficiente mana para un ataque mágico... golpea torpemente con su bastón";
                return new ResultadoAtaque(danioBaston, descripcion);
            }
        }
    }
}
