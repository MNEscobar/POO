﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscobarMatias_ProyectoIntegrador
{
    public static class ItemFactory
    {
        public static Item CrearPocionMenor() => new Pocion("Poción Pequeña", 20);
        public static Item CrearPocionMayor() => new Pocion("Gran Poción", 50);
        public static Item CrearEspada() => new Arma("Espada de Hierro", 5 );
        public static Item CrearHacha() => new Arma("Hacha de Guerra", 8);
        public static Item CrearPergamino() => new Pergamino("Pergamino de Escape", 0);

        public static Item CrearItemAleatorio()
        {
            Random random = new Random();
            int probabilidad = random.Next(100);

            if (probabilidad < 40) return CrearPocionMenor();
            if (probabilidad < 60) return CrearPocionMayor();
            if (probabilidad < 80) return CrearEspada();
            if (probabilidad < 90) return CrearHacha();
            return CrearPergamino();
        }
    }

}
