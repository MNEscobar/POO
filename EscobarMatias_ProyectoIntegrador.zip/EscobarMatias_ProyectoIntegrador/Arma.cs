﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscobarMatias_ProyectoIntegrador
{
    public class Arma : Item
    {
        public Arma(string nombre, int valor) 
            : base(nombre, valor) {}

        public override void Usar(Personaje objetivo)
        {
            objetivo.AumentarAtaque(Valor);
        }
    }
}