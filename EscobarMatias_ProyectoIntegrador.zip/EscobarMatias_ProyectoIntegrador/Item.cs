﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json.Serialization;

namespace EscobarMatias_ProyectoIntegrador
{
    [JsonDerivedType(typeof(Pocion), typeDiscriminator: "pocion")]
    [JsonDerivedType(typeof(Arma), typeDiscriminator: "arma")]
    [JsonDerivedType(typeof(Pergamino), typeDiscriminator: "pergamino")]

    public abstract class Item
    {
        public string Nombre { get; set; }
        public int Valor { get; set; }

        public Item() { }
        public Item(string nombre, int valor)
        {
            Nombre = nombre;
            Valor = Math.Max(0, valor);
        }
        public abstract void Usar(Personaje personaje);
    }
}