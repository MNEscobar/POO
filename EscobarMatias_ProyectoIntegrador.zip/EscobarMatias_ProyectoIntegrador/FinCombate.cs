﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscobarMatias_ProyectoIntegrador
{
    public class FinCombate : EstadoCombate
    {
        public override void Ejecutar(IUserInterface ui)
        {
            ui.MostrarMensaje("\n==============================================");
            ui.MostrarMensaje("              FIN DEL COMBATE                 ");
            ui.MostrarMensaje("==============================================");

            if (Contexto.Jugador.EstaVivo)
            {
                ui.MostrarMensaje($"¡FELICIDADES!  {Contexto.Jugador.Nombre} ha derrotado al {Contexto.EnemigoActual.Nombre}.");
            }
            else
            {
                ui.MostrarMensaje($"💀 Has sido derrotado por el {Contexto.EnemigoActual.Nombre}. Fin del juego.");
            }
        }
    }
}
