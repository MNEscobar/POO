﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.Json;

namespace EscobarMatias_ProyectoIntegrador
{
    public static class GestorDeDatos
    {
        private const string nombreArchivoJugador = "jugador.json";
        private const string nombreArchivoConfiguracion = "configuracion.json";

        private static readonly JsonSerializerOptions _opcionesJson = new JsonSerializerOptions
        {
            WriteIndented = true,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            IncludeFields = true
        };

        private static string RutaArchivoConfig => Path.Combine(AppDomain.CurrentDomain.BaseDirectory, nombreArchivoConfiguracion);

        public static string ObtenerRutaGuardado()
        {
            if (File.Exists(RutaArchivoConfig))
            {
                try
                {
                    string json = File.ReadAllText(RutaArchivoConfig);
                    Configuracion config = JsonSerializer.Deserialize<Configuracion>(json);

                    if (Directory.Exists(config.RutaPersonalizada))
                    {
                        return config.RutaPersonalizada;
                    }                   
                }
                catch 
                {
                    // Si hay un error al leer o desarializar, se retorna la ruta por defecto
                }
            }
            return AppDomain.CurrentDomain.BaseDirectory;
        }
        public static void CambiarRutaGuardado(string nuevaRuta)
        {
            if (!Directory.Exists(nuevaRuta))
            {
                throw new DirectoryNotFoundException("La ruta ingresada no existe. Por favor crea la carpeta primero.");
            }

            Configuracion config = new Configuracion { RutaPersonalizada = nuevaRuta };
            string json = JsonSerializer.Serialize(config, _opcionesJson);

            File.WriteAllText(RutaArchivoConfig, json);
        }
        public static void GuardarPartida(Personaje jugador)
        {
            string carpetaDestino = ObtenerRutaGuardado();
            string rutaCompleta = Path.Combine(carpetaDestino, nombreArchivoJugador);

            string json = JsonSerializer.Serialize(jugador, _opcionesJson);
            File.WriteAllText(rutaCompleta, json);
        }
        public static bool ExistePartidaGuardada()
        {
            string carpetaDestino = ObtenerRutaGuardado();
            string rutaCompleta = Path.Combine(carpetaDestino, nombreArchivoJugador);
            return File.Exists(rutaCompleta);
        }
        public static Personaje CargarPartida()
        {
            string carpetaDestino = ObtenerRutaGuardado();
            string rutaCompleta = Path.Combine(carpetaDestino, nombreArchivoJugador);

            if (!File.Exists(rutaCompleta)) return null;

            try
            {
                string json = File.ReadAllText(rutaCompleta);
                return JsonSerializer.Deserialize<Personaje>(json, _opcionesJson);
            }
            catch (JsonException)
            {
                return null;
            }
        }
        public static void BorrarDatos()
        {
            string carpetaDestino = ObtenerRutaGuardado();
            string rutaSave = Path.Combine(carpetaDestino, nombreArchivoConfiguracion);

            if (File.Exists(nombreArchivoJugador))
            {
                File.Delete(nombreArchivoJugador);
            }
            if (File.Exists(RutaArchivoConfig))
            {
                File.Delete(RutaArchivoConfig);
            }
        }
        private class Configuracion
        {
            public string RutaPersonalizada { get; set; }
        }
    }
}
