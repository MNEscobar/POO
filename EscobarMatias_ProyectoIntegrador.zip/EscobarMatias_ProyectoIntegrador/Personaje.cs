﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json.Serialization;
using static EscobarMatias_ProyectoIntegrador.IEstrategiaAtaque;

namespace EscobarMatias_ProyectoIntegrador
{
    [JsonDerivedType(typeof(Guerrero), typeDiscriminator: "guerrero")]
    [JsonDerivedType(typeof(Mago), typeDiscriminator: "mago")]
    public abstract class Personaje
    {
        public string Nombre { get; set; }
        public int Vida { get; set; }
        public int AtaqueBase { get; set; }
        public int DefensaBase { get; set; }

        [JsonIgnore]
        public bool EstaDefendiendo { get; set; }
        public Inventario Inventario { get; } = new Inventario();

        [JsonIgnore]
        public bool HaEscapado { get; set; } = false;

        [JsonIgnore]
        private IEstrategiaAtaque _estrategiaActual;

        protected Personaje()
        {
            // Constructor vacio para serialización
        }

        protected Personaje(string nombre, int vida, int ataque, int defensa, IEstrategiaAtaque estrategiaInicial)
        {
            Nombre = nombre;
            Vida = Math.Max(0, vida);
            AtaqueBase = Math.Max(0, ataque);
            DefensaBase = Math.Max(0, defensa);

            _estrategiaActual = estrategiaInicial ?? throw new ArgumentNullException(nameof(estrategiaInicial));
        }
        public void CambiarEstrategia(IEstrategiaAtaque nuevaEstrategia)
        {
            if (nuevaEstrategia != null)
            {
                _estrategiaActual = nuevaEstrategia;
            }
        }
        public ResultadoAtaque Atacar()
        {
            return _estrategiaActual.EjecutarAtaque(this);
        }
        public void Defender()
        {
            EstaDefendiendo = true;
        }
        public void TerminarDefensa()
        {
            EstaDefendiendo = false;
        }

        public virtual void RecibirDanio(int danio)
        {
            if (EstaDefendiendo)
            {
                danio /= 2;
            }

            int danioRecibido = Math.Max(0, danio - DefensaBase);
            Vida = Math.Max(0, Vida - danioRecibido);
        }
        public bool EstaVivo => Vida > 0;

        public void Curar(int cantidad)
        {
            if (EstaVivo) Vida = Math.Min(Vida + cantidad, 100);
        }
        public void AumentarAtaque(int cantidad)
        {
            if (cantidad > 0)
            {
                AtaqueBase += cantidad;
            }
        }

        public virtual bool IntentarGastarMana(int cantidad) => false;
        public override string ToString()
        {
            return $"{Nombre} (Base) | HP: {Vida} | ATK: {AtaqueBase} | DEF: {DefensaBase}";
        }

        protected void EstablecerEstrategia(IEstrategiaAtaque estrategia)
        {
            _estrategiaActual = estrategia;
        }
    }
}
