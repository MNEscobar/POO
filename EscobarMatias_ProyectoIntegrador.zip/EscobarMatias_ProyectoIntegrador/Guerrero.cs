﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscobarMatias_ProyectoIntegrador
{
    public class Guerrero : Personaje
    {
        public int Armadura { get; set; }

        public Guerrero() : base()
        {
            EstablecerEstrategia(new AtaqueFisico());
        }

        public Guerrero(string nombre, int vida, int ataque, int defensa, int armadura)
            : base(nombre, vida, ataque, defensa, new AtaqueFisico())
        {
            Armadura = Math.Max(0, armadura);
        }

        public override void RecibirDanio(int danioBruto)
        {
            int danioReducido = Math.Max(0, danioBruto - Armadura);
            base.RecibirDanio(danioReducido);
        }
    }
}
