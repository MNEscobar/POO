﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscobarMatias_ProyectoIntegrador
{
    public class TurnoJugador : EstadoCombate
    {
        private static readonly Dictionary<int, string> OpcionesMenu = new Dictionary<int, string>
        {
            { 1, "Atacar" },
            { 2, "Defenderse" },
            { 3, "Inventario" }
        };

        public override void Ejecutar(IUserInterface ui)
        {
            ui.MostrarEstado(Contexto.Jugador, Contexto.EnemigoActual);
            if (!Contexto.Jugador.EstaVivo || !Contexto.EnemigoActual.EstaVivo)
            {
                Contexto.CambiarEstado(new FinCombate());
                return;
            }
            int eleccion = ui.SeleccionarOpcion(OpcionesMenu);

            switch (eleccion)
            {
                case 1:
                    var resultado = Contexto.Jugador.Atacar();
                    Contexto.Jugador.TerminarDefensa();
                    Contexto.EnemigoActual.RecibirDanio(resultado.PuntosDeDanio);
                    ui.MostrarMensaje(resultado.MensajeAtaque);
                    ui.MostrarMensaje($"¡Golpe efectivo! Causó {resultado.PuntosDeDanio} de daño.");
                    ui.EsperarTecla();

                    Contexto.CambiarEstado(new TurnoEnemigo());
                    break;
                case 2:
                    Contexto.Jugador.Defender();

                    ui.MostrarMensaje($"{Contexto.Jugador.Nombre} se prepara para defenderse.");
                    ui.MostrarMensaje("El daño del enemigo se reducirá en su próximo ataque.");
                    
                    ui.EsperarTecla();
                    Contexto.CambiarEstado(new TurnoEnemigo());
                    break;
                case 3:
                    Contexto.Jugador.TerminarDefensa(); 
                    ui.MostrarMensaje("Abre el inventario.");
                    int indice = ui.SeleccionarItem(Contexto.Jugador.Inventario.Items);
                    if (indice != -1)
                    {
                        var item = Contexto.Jugador.Inventario.Items[indice];
                        ui.MostrarMensaje($"Usaste: {item.Nombre}");
                        Contexto.Jugador.Inventario.UsarItem(Contexto.Jugador, indice);
                        ui.EsperarTecla();

                        if (Contexto.Jugador.HaEscapado)
                        {
                            ui.MostrarMensaje(" ¡Has usado el Pergamino de Escape! Huiste exitosamente del combate.");
                            ui.EsperarTecla();
                            Contexto.CambiarEstado(new FinCombate());
                        }
                        else
                        {
                            Contexto.CambiarEstado(new TurnoEnemigo());
                        }
                    }
                    else
                    {
                        ui.MostrarMensaje("Cerraste el inventario.");
                    }
                    break;
                default:
                    ui.MostrarMensaje("Opcion no valida. Pierdes el turno");
                    Contexto.CambiarEstado(new TurnoEnemigo());
                    break;
            }
        }
    }
}
