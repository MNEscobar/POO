﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscobarMatias_ProyectoIntegrador
{
    public abstract class EstadoCombate
    {
        protected SistemaCombate? Contexto { get; private set; }

        public void SetContexto(SistemaCombate contexto)
        {
            Contexto = contexto;
        }
        public abstract void Ejecutar(IUserInterface ui);
    }
}
