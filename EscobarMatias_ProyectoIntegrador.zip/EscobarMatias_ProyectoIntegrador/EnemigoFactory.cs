﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscobarMatias_ProyectoIntegrador
{
    public class EnemigoFactory
    {
        private static readonly List<Enemigo> _prototipos = new List<Enemigo>
        {
            Enemigo.CrearPrototipo("Bandido novato", 30, 5),
            Enemigo.CrearPrototipo("Esqueleto Arquero", 50, 10),
            Enemigo.CrearPrototipo("Orco", 100, 20),
            Enemigo.CrearPrototipo("Brujo Oscuro", 60, 15)
        };

        public static Enemigo CrearEnemigoAleatorio()
        {
            var random = new Random();
            int indice = random.Next(_prototipos.Count);
            Enemigo seleccionado = _prototipos[indice];

            return Enemigo.CrearPrototipo(seleccionado.Nombre, seleccionado.Vida, seleccionado.AtaqueBase);
        }
    }
}
