﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscobarMatias_ProyectoIntegrador
{
    public struct ResultadoAtaque
    {
        public int PuntosDeDanio { get; }
        public string MensajeAtaque { get; }

        public ResultadoAtaque(int danio, string descripcionAtaque)
        {
            PuntosDeDanio = danio;
            MensajeAtaque = descripcionAtaque;
        }
    }
    public interface IEstrategiaAtaque
    {
        ResultadoAtaque EjecutarAtaque(Personaje atacante);
    }
}
