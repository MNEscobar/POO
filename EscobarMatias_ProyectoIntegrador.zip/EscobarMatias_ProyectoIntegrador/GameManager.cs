﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscobarMatias_ProyectoIntegrador
{
    public class GameManager
    {
        private readonly SistemaCombate _sistemaCombate;
        private readonly IUserInterface _ui;
        private Personaje? _jugador;

        public GameManager(SistemaCombate sistemaCombate, IUserInterface ui)
        {
            _sistemaCombate = sistemaCombate;
            _ui = ui;
        }

        public void IniciarJuego()
        {
            bool salir = false;
            while (!salir)
            {
                Console.Clear();
                _ui.MostrarMensaje("=== Menu Principal ===");
                _ui.MostrarMensaje($"Ruta de guardado actual: {GestorDeDatos.ObtenerRutaGuardado}");

                Dictionary<int, string> opcionesMenu = new Dictionary<int, string>
                {
                    {1, "Jugar / Continuar Aventura" },
                    {2, "Configurar ruta de guardado" },
                    {3, "Borrar datos guardados" },
                    {4, "Salir" }
                };
                int eleccion = _ui.SeleccionarOpcion(opcionesMenu);

                switch (eleccion)
                {
                    case 1:
                        EjecutarAventura();
                        break;
                    case 2:
                        ConfigurarDirectorio();
                        break;
                    case 3:
                        ConfirmarBorrado();
                        break;
                    case 4:
                        salir = true;
                        break;
                    default:
                        _ui.MostrarMensaje("Opcion invalida.");
                        break;
                }
            }
            _ui.MostrarMensaje("Gracias por jugar. ¡Hasta la próxima!");
        }
        private void ConfigurarDirectorio()
        {
            _ui.MostrarMensaje("Ingrese la nueva ruta completa para guardar los archivos:");
            _ui.MostrarMensaje("(Ejemplo: C:\\Juegos\\MiRPG )");
            string nuevaRuta = _ui.LeerEntrada();

            try
            {
                GestorDeDatos.CambiarRutaGuardado(nuevaRuta);
                _ui.MostrarMensaje("Ruta de guardado actualizada correctamente.");
            }
            catch (Exception ex)
            {
                _ui.MostrarMensaje($"Error al cambiar la ruta: {ex.Message}");
            }
            _ui.EsperarTecla();
        }
        private void ConfirmarBorrado()
        {
            _ui.MostrarMensaje("¿Estás seguro de borrar TODOS los datos y progreso? [1]Si [2]No \"");
            if (_ui.LeerEntrada() == "1")
            {
                GestorDeDatos.BorrarDatos();
                _jugador = null;
                _ui.MostrarMensaje("Datos borrados correctamente.");
            }
            _ui.EsperarTecla();
        }
        private void EjecutarAventura()
        {
            if (GestorDeDatos.ExistePartidaGuardada())
            {
                _ui.MostrarMensaje("Cargando partida guardada...");
                _jugador = GestorDeDatos.CargarPartida();

                if (_jugador != null)
                {
                    _ui.MostrarMensaje($"¡Bienvenido de nuevo, {_jugador.Nombre}!");
                }
                else
                {
                    _ui.MostrarMensaje("Error: El archivo de guardado está dañado. Se creará uno nuevo.");
                }
            }
            if (_jugador == null)
            {
                _jugador = CrearPersonaje();
                if (_jugador is Guerrero)
                {
                    _jugador.Inventario.AgregarItem(ItemFactory.CrearEspada());
                    _jugador.Inventario.AgregarItem(ItemFactory.CrearPergamino());
                    _ui.MostrarMensaje("Has comenzado con una Espada en tu inventario.");
                }
                else
                {
                    _jugador.Inventario.AgregarItem(ItemFactory.CrearPocionMenor());
                    _ui.MostrarMensaje("Has comenzado con una Pocion Menor en tu inventario.");
                }
                _ui.MostrarMensaje("Partida nueva creada y guardada.");
                GestorDeDatos.GuardarPartida(_jugador);
            }
            bool continuar = true;
            while (continuar && _jugador?.EstaVivo == true)
            {
                Enemigo enemigo = EnemigoFactory.CrearEnemigoAleatorio();
                _ui.MostrarMensaje($"\n---------------------------------");
                _ui.MostrarMensaje($"¡Aparece un {enemigo.Nombre}!");
                _ui.MostrarMensaje($"---------------------------------");

                // _jugador es no-nulo aquí por la condición del while; usamos el operador ! para el compilador.
                _sistemaCombate.IniciarCombate(_jugador!, enemigo);

                while (!_sistemaCombate.CombateFinalizado)
                {
                    _sistemaCombate.EjecutarTurno(_ui);
                }
                if (_jugador?.EstaVivo == true)
                {
                    if (_jugador.HaEscapado)
                    {
                        _ui.MostrarMensaje("Escapaste del combate sano y salvo.");
                        _ui.MostrarMensaje("No obtuviste ninguna recompensa.");
                        _jugador.HaEscapado = false;
                    }
                    else
                    {
                        _ui.MostrarMensaje($"=== ¡VICTORIA! === )");
                        Item recompensa = ItemFactory.CrearItemAleatorio();
                        _jugador!.Inventario.AgregarItem(recompensa);
                        _ui.MostrarMensaje($"Saqueando al enemigo encuentras: {recompensa.Nombre}");
                    }
                    _ui.MostrarMensaje("Guardando progreso...");
                    GestorDeDatos.GuardarPartida(_jugador);

                    _ui.MostrarMensaje("¿Quieres seguir explorando? [1]SI / [2]NO");
                    continuar = (_ui.LeerEntrada() == "1");
                }
                else
                {
                    continuar = false;
                }
            }
            _ui.MostrarMensaje("\n--- GAME OVER ---");
        }
        public Personaje CrearPersonaje()
        {
            string nombre = string.Empty;
            bool nombreValido = false;

            while (!nombreValido)
            {
                try
                {
                    _ui.MostrarMensaje("Ingrese el nombre de su héroe:");
                    nombre = _ui.LeerEntrada();

                    if (string.IsNullOrWhiteSpace(nombre))
                    {
                        throw new JuegoException("El nombre no puede estar vacio. Intente nuevamente.");
                    }
                    if (nombre.Length < 3 || nombre.Length > 20)
                    {
                        throw new JuegoException("El nombre debe tener entre 3 y 20 caracteres. Intente nuevamente.");
                    }
                    nombreValido = true;
                }
                catch (JuegoException ex)
                {
                    _ui.MostrarMensaje($"Error: {ex.Message}");
                }
            }

            int claseElegida = PedirClase();
            switch (claseElegida)
            {
                case 1:
                    _jugador = new Guerrero(nombre, vida: 120, ataque: 15, defensa: 8, armadura: 5);
                    break;
                case 2: 
                    _jugador = new Mago(nombre, vida: 90, ataque: 10, defensa: 5, mana: 100);
                    break;
                default:
                    _ui.MostrarMensaje("Opción inválida: se asigna Guerrero por defecto.");
                    _jugador = new Guerrero(nombre, vida: 80, ataque: 10, defensa: 5, armadura: 0);
                    break;
            }

            _ui.MostrarMensaje($"Personaje creado: {_jugador.Nombre} ({_jugador.GetType().Name})");
            return _jugador;
        }

        private int PedirClase()
        {
            Dictionary<int, string> opcionesClase = new Dictionary<int, string>
        {
            { 1, "Guerrero (Físico)" },
            { 2, "Mago (Mágico)" }
        };
            return _ui.SeleccionarOpcion(opcionesClase);
        }
    }
}