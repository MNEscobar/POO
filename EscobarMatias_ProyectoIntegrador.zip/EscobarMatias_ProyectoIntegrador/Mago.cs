﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscobarMatias_ProyectoIntegrador
{
    public class Mago : Personaje
    {
        public int Mana { get; set; }

        public Mago() : base()
        {
            EstablecerEstrategia(new AtaqueMagico());
        }

        public Mago(string nombre, int vida, int ataque, int defensa, int mana)
            : base(nombre, vida, ataque, defensa, new AtaqueMagico())
        {
            Mana = Math.Max(0, mana);
        }
        public override bool IntentarGastarMana(int cantidad)
        {
            if (Mana >= cantidad)
            {
                Mana -= cantidad;
                return true; 
            }
            return false;
        }
    }
}
