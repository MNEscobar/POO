﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscobarMatias_ProyectoIntegrador
{
    public class Pocion : Item
    {
        public Pocion(string nombre, int curacion)
            : base(nombre, curacion) { }

        public override void Usar(Personaje objetivo)
        {
            objetivo.Curar(Valor);
        }
    }
}
