﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscobarMatias_ProyectoIntegrador
{
    public class Pergamino : Item
    {
        public Pergamino() : base() { }

        public Pergamino(string nombre, int valor) : base(nombre, valor) { }

        public override void Usar(Personaje personaje)
        {
            personaje.HaEscapado = true;
        }
    }
}
