﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscobarMatias_ProyectoIntegrador
{
    public class JuegoException : Exception
    {
        public JuegoException(string mensaje) : base(mensaje) { }
    }
}
