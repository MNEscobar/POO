﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscobarMatias_ProyectoIntegrador
{
    public class SistemaCombate
    {
        public Personaje Jugador { get; private set; } = null!;
        public Enemigo EnemigoActual { get; private set; } = null!;
        public EstadoCombate? _estadoActual;
        public bool CombateFinalizado => _estadoActual is FinCombate;

        public void CambiarEstado(EstadoCombate nuevoEstado)
        {
            _estadoActual = nuevoEstado;
            _estadoActual.SetContexto(this);
        }
        public void IniciarCombate(Personaje jugador, Enemigo enemigo)
        {
            Jugador = jugador;
            EnemigoActual = enemigo;
            CambiarEstado(new TurnoJugador());
        }
        public void EjecutarTurno(IUserInterface ui)
        {
            if (_estadoActual != null)
            {
                _estadoActual.Ejecutar(ui);
            }
        }
    }
}
