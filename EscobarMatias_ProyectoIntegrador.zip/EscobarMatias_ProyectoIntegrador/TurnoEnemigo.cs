﻿using EscobarMatias_ProyectoIntegrador;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscobarMatias_ProyectoIntegrador
{
    public class TurnoEnemigo : EstadoCombate
    {
        public override void Ejecutar(IUserInterface ui)
        {
            var jugador = Contexto.Jugador;
            var enemigo = Contexto.EnemigoActual;

            if (!enemigo.EstaVivo)
            {
                Contexto.CambiarEstado(new FinCombate());
                return;
            }
            int danioBruto = enemigo.Atacar();
            if (Contexto.Jugador.EstaDefendiendo)
            {
                ui.MostrarMensaje($"{jugador.Nombre} bloquea el ataque del {enemigo.Nombre} y reduce el daño a la mitad.");
            }

            jugador.RecibirDanio(danioBruto);

            ui.MostrarMensaje($"El {enemigo.Nombre} ataca a {jugador.Nombre} y causa {danioBruto} puntos de daño.");
            ui.EsperarTecla();
            ui.MostrarEstado(jugador, enemigo);

            if (!jugador.EstaVivo)
            {
                ui.MostrarMensaje($"{jugador.Nombre} ha sido derrotado.");
                Contexto.CambiarEstado(new FinCombate());
            }
            else
            {
                Contexto.CambiarEstado(new TurnoJugador());
            }
        }
    }
}
