﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EscobarMatias_ProyectoIntegrador
{
    public class AtaqueFisico : IEstrategiaAtaque
    {
        public ResultadoAtaque EjecutarAtaque(Personaje atacante)
        {
            int danio = atacante.AtaqueBase;
            string descripcion = $"{atacante.Nombre} ataca con su arma causando {danio} de daño físico.";

            return new ResultadoAtaque(danio, descripcion);
        }
    }
}
